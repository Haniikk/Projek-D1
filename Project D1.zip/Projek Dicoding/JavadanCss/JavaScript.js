console.log("Hallo, Kawan!");
const nama = prompt("Kalau boleh tau, siapa namamu?");
const jawab = prompt("Apakah kamu ingin berkenalan denganku?");
 
const user = {
   kunci: {
       name: nama,
   },
   answer: jawab
};
 
if (user.answer === "ya") {
   alert("Great! Perkenalkan, namaku Umi. Silahkan baca portofolio jika ingin tau lebih banyak tentangku, " + user.kunci.name + " " + "!");
} else (user.answer === "tidak")
   alert("Sayang sekali, mungkin saja aku kurang menarik. Sepertinya begitu kan, " + user.kunci.name + " " + "!");